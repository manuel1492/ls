#!/bin/bash

cp -rpv ../ggml/src/ggml.c          ./ggml.c
cp -rpv ../ggml/src/ggml-cuda.cu    ./ggml-cuda.cu
cp -rpv ../ggml/src/ggml-cuda.h     ./ggml-cuda.h
cp -rpv ../ggml/include/ggml/ggml.h ./ggml.h
